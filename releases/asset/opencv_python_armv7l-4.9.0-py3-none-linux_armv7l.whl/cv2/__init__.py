import importlib.util
import sys
import os

# Загружаем .so файл
spec = importlib.util.spec_from_file_location('cv2', os.path.join(os.path.dirname(__file__), '__init__.so'))
module = importlib.util.module_from_spec(spec)
sys.modules['cv2'] = module
spec.loader.exec_module(module)

# Экспортируем всё в текущее пространство имён
globals().update(module.__dict__)
